# Portal Sombori Kepulauan

Website PHP 8 + SQLite, tanpa framework/dependency eksternal.

## Instalasi
1. Upload folder ke hosting yang mendukung PHP 8+ dan SQLite.
2. Pastikan folder project dapat ditulis agar `data.sqlite` bisa dibuat.
3. Buka `/` untuk website.
4. Buka `/admin/` untuk dashboard.

## Login awal
- Username: `admin`
- Password: `admin123`

Segera ganti password di implementasi produksi dengan sistem password hash yang proper.

## Catatan
Struktur dan konten awal mengikuti bagian yang tersedia pada situs referensi: Beranda, Profil, Layanan, Berita, Galeri, Desa, Pengaduan, dan area admin. Data dapat dikembangkan lagi sesuai kebutuhan pemerintahan/desa.
